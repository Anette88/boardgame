// Data from JSON file to be displayed in cards

//fetch('API/characters.json')
	//.then(result => result.json())
	//.then((res) => {
		//retrieveData(res);
	//})
	//.catch(err => console.log(err))

//function retrieveData(info) {

//}


function chooseCharacter(character) {
  if (character === "Tormund") {
    window.localStorage.setItem("character", "Tormund");
  }
  else if (character === "Ramsay") {
    window.localStorage.setItem("character", "Ramsay");
  }
  else if (character === "Arya") {
    window.localStorage.setItem("character", "Arya");
  }
  else if (character === "Brienne") {
    window.localStorage.setItem("character", "Brienne");
  }
  else if (character === "Daenerys") {
    window.localStorage.setItem("character", "Daenerys");
  }
  else if (character === "Tyrion") {
    window.localStorage.setItem("character", "Tyrion");
  }
  else if (character === "Samwell") {
    window.localStorage.setItem("character", "Samwell");
  }
	location.href="board.html";
}
